# pyright: reportInvalidTypeForm=false,reportMissingModuleSource=false

import bpy
from bpy.types import Panel

class PZ_HumanRig_TestPanel(Panel):
    bl_idname = "VIEW3D_PT_pz_human_rig_test_panel"
    bl_label = "Test"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Zomboid"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        try:
            return context.active_object.get("rig_id") == "ZOMBOID_Human"
        except:
            return False

    def draw(self, context):

        # Get all data
        addon_prefs = bpy.context.preferences.addons['PZ_BlenderToolkit'].preferences
        animation_properties = context.active_object.pz_animation_properties

        # Create the initial layout
        layout = self.layout

        
        

