# pyright: reportInvalidTypeForm=false,reportMissingModuleSource=false

import bpy
from bpy.types import PropertyGroup, Collection
from bpy.props import IntProperty, PointerProperty


class PZ_SceneProperties(PropertyGroup):

    # These properties and methods relate to the storage of human rig objects in the scene

    def update_human_rig_active_index(self, context):
        if self.human_rig_active_index == -1:
            return
        selected_rig = context.scene.pz_human_rigs[self.human_rig_active_index]
        if selected_rig:
            if context.active_object:
                if context.active_object.mode == 'OBJECT':
                    bpy.ops.object.select_all(action='DESELECT')
                    selected_rig.rig_object.select_set(True)
                    context.view_layer.objects.active = selected_rig.rig_object
                elif context.active_object.mode == 'POSE':
                    bpy.ops.object.mode_set(mode='OBJECT')
                    bpy.ops.object.select_all(action='DESELECT')
                    selected_rig.rig_object.select_set(True)
                    context.view_layer.objects.active = selected_rig.rig_object
                    bpy.ops.object.mode_set(mode='POSE')
            else:
                context.view_layer.objects.active = selected_rig.rig_object
                context.view_layer.objects.active = selected_rig.rig_object

    human_rig_active_index: IntProperty(
           default=-1,
           update=update_human_rig_active_index
    )

    rig_parent_collection: PointerProperty(
        name='Parent Collection',
        description='The collection that the new rig will be added to. If left blank, it will be added to the Scene collection',
        type=Collection
    )

    # These properties and methods relate to the storage of PZ item models in the scene
